/* *****************************************************
  EZ4-64 
  ******************************************************
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>

#define PROG_NAME "EZ4-64.exe"
#define false 0
#define true 1

typedef unsigned char u8;
typedef unsigned int u32;


// .from ndstool
//chk=0:for i=0A0h to 0BCh:chk=chk-[i]:next:chk=(chk-19h) and 0FFh
typedef struct
{
	unsigned long	start_code;			// B instruction
	unsigned char	logo[0xA0-0x04];	// logo data
	char			title[0xC];			// game title name
	unsigned long	game_code;			//
	unsigned short	maker_code;			//
	unsigned char	fixed;				// 0x96
	unsigned char	unit_code;			// 0x00
	unsigned char	device_type;		// 0x80
	unsigned char	unused[7];			//
	unsigned char	game_version;		// 0x00
	unsigned char	complement;			// 800000A0..800000BC
	unsigned short	checksum;			// 0x0000
} Header;

// Calculate Header complement check
char HeaderComplement(Header *header)
{
	int n;
	char c = 0;
	char *p = (char *)&header + 0xA0;
	for (n=0; n<0xBD-0xA0; n++)
	{
		c += *p++;
	}
	return -(0x19+c);
}
// .end from ndstool

char *outputFilename = NULL;

FILE *in1, *out;       /* In and out FILE Streams to read/write data */

void usage()
{
printf("EZ4-64 - Patches SRAM string to 64k\n");
printf("-----------------------------------\n");
printf("Invalid command line.\n");
printf("Usage:\n\t%s infile.nds\n", PROG_NAME);
printf("Or use Windows drag and drop\n");
printf("-----------------------------------\n");
}

int main(int argc, char *argv[])
{
    int count = 0;
    char tmp;
    long lSize;
    char srcFile[MAXPATHLEN], dstFile[MAXPATHLEN], savFile[MAXPATHLEN];
    char* buffer;
    char saver[7] = {0x00, 0x00, 0x00, 0x9C, 0x01, 0x10, 0x00};//{0xC0, 0xDF, 0x0C, 0x9C, 0x01, 0x10, 0x00};

    if((argc != 2) || (argv[1] == NULL))
    {  /* Error check the command line */
        usage();                  /* Display Usage Information on error */
        printf("\npress <enter> to quit...\n");
        fgetc(stdin);
        return 0;               /* Exit Program returning 0 - no error */
    }

    if (( in1 = fopen(argv[1], "rb")) == NULL) /* Error Check File Streams */
    {
        printf("Error opening %s.\n", argv[1]);
        printf("\npress <enter> to quit...\n");
        fgetc(stdin);
        return 0;
    }

    outputFilename = argv[1];
    strcpy (srcFile, outputFilename);
    strcpy (dstFile, outputFilename);
    strcpy (savFile, outputFilename);
    strcat (savFile,".sav");

    strcat (dstFile,".bin");

    if (( out = fopen(dstFile, "wb")) == NULL)
    {
        fclose(in1);
        printf("Error opening %s.\n", dstFile);
        printf("\npress <enter> to quit...\n");
        fgetc(stdin);
        return 0;
    }

    printf("EZ4-64 0.2\n"
           "----------\n");
    printf("input file : %s\n", srcFile);
    printf("output file: %s\n", dstFile);
    printf("saver file : %s\n\n", savFile);

// obtain file size.
    fseek (in1 , 0 , SEEK_END);
    lSize = ftell (in1);
    rewind (in1);

// read the header into the buffer and get the complement
    buffer = (char*)malloc(512);
    fread(buffer, 512, 1, in1);
    rewind (in1);
    Header *header = (Header *)buffer;
    while (count < 7)
    {
        header->unused[count]=saver[count];
        count++;
    }
    header->complement = 0;
    header->checksum = 0;	// must be 0
    header->complement = HeaderComplement(header);
    printf("comp: %x\n\n",header->complement);


// make a copy of the input file and patch the header
    printf("Copying file...\n\n");
    count = 0;
    while (count < lSize)
    {
        tmp=getc(in1);
        if (count < 512) {putc(buffer[count], out);}
//        if ((count > 180) && (count < 188)) { putc(saver[count-181],out);}
//        else if (count == 190) { putc(comp,out);}
        else putc(tmp, out);
        count++;
    }

    fclose(in1);
    fclose(out);

// open a new file for the save and 00 fill it to 64K

    if (( out = fopen(savFile, "wb")) == NULL)
    {
        printf("Error opening %s.\n", dstFile);
        printf("\npress <enter> to quit...\n");
        fgetc(stdin);
        return 0;
    }
    printf("Making blank save file...\n\n");
    count = 0;
    while (count < (64*1024))
    {
        putc(0x00, out);
        count++;
    }
    fclose(out);
    free(buffer);
    printf("Finished......Success!\n\nYou will have to rename the .out and .sav to your preference\nand place them in the proper places\n\n");
    printf("press <enter> to quit...\n");
    fgetc(stdin);

    return 0;
}
